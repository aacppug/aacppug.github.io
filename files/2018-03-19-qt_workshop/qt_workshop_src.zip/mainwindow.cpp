#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "dialog.h"

#include <QtWidgets/QtWidgets>

MainWindow::MainWindow(QWidget *parent) :
  QMainWindow(parent),
  ui(new Ui::MainWindow)
{
  ui->setupUi(this);
  connect(ui->actionDoSomething, &QAction::triggered, this, &MainWindow::slotSomething);
}

MainWindow::~MainWindow()
{
  delete ui;
}

void MainWindow::slotSomething()
{
  QMessageBox::information(this, tr("Hello World"), tr("Aarhus C++ User Group with a longer text"));
}

void MainWindow::on_actionDoSomething2_triggered()
{
  Dialog *dlg = new Dialog;
  // dlg->show();
  dlg->exec();
}
