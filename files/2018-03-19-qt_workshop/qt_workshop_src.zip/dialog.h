#ifndef DIALOG_H
#define DIALOG_H

#include <QDialog>

class QLabel;

class Dialog : public QDialog
{
  Q_OBJECT
public:
  Dialog();
protected slots:
  void setCount(int value);
private:
  QLabel *l;
};

#endif // DIALOG_H
