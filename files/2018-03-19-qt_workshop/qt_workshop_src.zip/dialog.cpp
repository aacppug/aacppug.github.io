#include "dialog.h"
#include <QtWidgets/QtWidgets>

Dialog::Dialog()
{
  QVBoxLayout *vbox = new QVBoxLayout(this);
  l = new QLabel();
  vbox->addWidget(l);
  const int startCount = 5;
  setCount(startCount);

  QSpinBox *spinBox = new QSpinBox();

  QHBoxLayout *hbox = new QHBoxLayout;
  hbox->addWidget(new QLabel(tr("Count:")));
  hbox->addWidget(spinBox);
  vbox->addLayout(hbox);
  spinBox->setValue(startCount);

  connect(spinBox, SIGNAL(valueChanged(int)),
          this, SLOT(setCount(int)));
}

void Dialog::setCount(int value)
{
  l->setText(tr("There were %1 rabbits").arg(value));
}
